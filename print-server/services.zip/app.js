const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();
const path = require("path");
const authRoutes = require("./routes/authRouter");
const printRoutes = require("./routes/printRouter");

const pool = require("./config/db");
const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("API Running...");
});

// Test Database Connection
app.get("/db-test", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT NOW() AS currentTime");
    res.json({
      success: true,
      message: "Database Connected Successfully",
      data: rows,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

app.use("/api/auth", authRoutes);
app.use("/api/print", printRoutes);

const port = process.env.PORT || 3500;

app.listen(port, () => {
  console.log(`server  running on ${port}`);
});
